package com.example.Deploy.Environments.Variables2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeployEnvironmentsVariables02Application {

	public static void main(String[] args) {
		SpringApplication.run(DeployEnvironmentsVariables02Application.class, args);
	}

}
